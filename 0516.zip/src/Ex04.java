
/*
 * 숫자 int 			4byte
 * 문자 String 		클래스
 * boolean 			참 or 거짓
 * char 			'A' 			
 */


public class Ex04 {
	
	/*
	 * 문자열 결합연산자(+)
	 * 1. 산술연산자 : 덧셈
	 * 2. 문자열 결합연산자: 두 항을 하나로 연결
	 */
		
	public static void main(String[] args) {
			
	 int kor = 91; 	//	국어점수 - 91 	
	 int eng = 85;  //	영어점수 - 85
	 int mat = 77;  // 	수학점수 - 77
	 
	int tot = kor + eng + mat;
	int avg = tot / 3 ;  
	 
	 
	 System.out.println("국어점수 : " + kor);
	 System.out.println("영어점수 : " + eng);
	 System.out.println("수학점수 : " + mat);
	 System.out.println("총    점 : " + tot);
	 System.out.println("평    균 : " + avg);
	 System.out.println("평    균 : " + (kor+eng+mat)/3);
	 System.out.println("총    점 : " + kor+eng+mat);
	 System.out.println("총    점 : " + (kor+eng+mat));
	
	//System.out.println("총    점 : " + (kor+eng+mat)); 
	//System.out.println("평    균 : " + ((kor+eng+mat)/3));
	// + 결합 연산자
	 
	 //1. 산술연산자
	 System.out.println(10 + 20);
	 
	 //2 . 문자열 결합연산자
	 
	 System.out.println("name : " + "홍길동");
	 System.out.println("avg  : " + 105);
	}

}
