
/*
 * java 프로그램 특징
 * 1.객체지향 프로그램이다.
 * 2.클래스 단위로 프로그램을 작성한다.
 * 3.한 문장은 세미콜론(;)으로 끝난다.
 * 4.클래스의 이름은 대문자로 시작한다.
 *   메서드는 소문자() 형태로 시작한다.
 * 5.main() : 프로그램의 시작점을 의미한다.   
 */


public class Ex03 {public static void main(String[] args) {
	
			//JVM : main()을 실행한다.
	     System.out.println("프로그램 시작");
	     System.out.print("java");
	     System.out.print("programming!!");
	     System.out.print("\n프로그램 종료");

	     //  \n : 줄바꿈을 제공하는 제어문자
}

}
