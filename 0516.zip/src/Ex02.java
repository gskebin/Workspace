// 한 줄 주석

/*
 * 두 줄 이상 주석
 * 작성자 : 홍길동
 * 작성일 : 2016.05.16
 * 내용   : 자바 기초 
 */

public class Ex02 {
	
	//main 메서드(기능,함수,function)
	//시작점(JVM이 가장 먼저 찾는 메서드이다)

	public static void main(String[] args) {
	
			System.out.println("*** 홍길동 성적표 ***");
			System.out.println("국어점수 : 80점");
			System.out.println("영어점수 : 80점");
			System.out.println("수학점수 : 80점");
			System.out.println("총   점  : 240점");
			System.out.println("평   균  : 80점");
			
			
			/* a=10 우변에 값을 좌변에 대입하라
			 * 가로가 있는것 메소드 (기능)
			 * System.out : 표준출력장치(모니터,콘솔)
			 * println() : 지정된 장치에 결과를 출력하라는 메서드
			 *      ln : Line(출력 후에 줄바꿈하라)
			 *       
			 */
	}

}
