
public class Ex01 {

			public static void main(String[] args) {
			
			  //표준출력장치(모니터)를 이용해서 ()안에 내용을 출력하시오.
		
				System.out.println("안흥섭");
				System.out.println("01025870232");
				System.out.println("마포구토정로242");
				System.out.println("gskebin@naver.com");
				
			}
}
