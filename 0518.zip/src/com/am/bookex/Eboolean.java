package com.am.bookex;

public class Eboolean {

	
		public static void main(String[] args) {
			
			int a = 90, b = 80 ; 
			boolean c = a>b ;
			
			String s = c ? "a는 b보다 크다" : "a는 b보다 작다";
			System.out.println(s);
			
			
		}
}
