package com.am.bookex;

public class Echar {

	
		public static void main(String[] args) {
			
			char c = 'a';
			System.out.println("c의 값 : "+ c);
			
		}
}
