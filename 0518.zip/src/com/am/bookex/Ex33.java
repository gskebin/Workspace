package com.am.bookex;

public class Ex33 {

	
		public static void main(String[] args) {
			
			int su1 =51;
			String str ;
			if(su1>=50) str = "50이상";
			else 
				str="50미만";
			System.out.println(str+"입니다");
			
		}
}
