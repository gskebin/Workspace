package com.am.bookex;

public class E정보처리 {

	
		public static void main(String[] args) {
		
			
			int su1 = 60;
			String res = (su1>=60) ? "합격" : "불합격";
				
			System.out.println("정보처리 시험결과 : " +res);
			
			int gender = 1 ; //성별
			res = (gender == 1) ? "남자" : "여자";
			System.out.println("결과: " + res);
		}
		
}
