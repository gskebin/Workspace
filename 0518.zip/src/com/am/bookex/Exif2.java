package com.am.bookex;

public class Exif2 {

	
		public static void main(String[] args) {
			
			//if ~ else 문
			
			System.out.println("시작");
			int a = 3;
			
			
			if(a==1){
				System.out.println("a는 1입니다");
			
			}	else if(a==2){
				System.out.println("a는 2입니다");
			}    else {
				System.out.println("a는 1도 2도 아닙니다");
			}
			
			
		}
		
}
