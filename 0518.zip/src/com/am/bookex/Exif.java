package com.am.bookex;

public class Exif {

	
		public static void main(String[] args) {
			
		/*
		 * if (true) {//조건이 true 일 경우 // 실행될 실행문
		 * 				}
		 */
			
			
		//동등비교
//		  경우 수 1,2,3	
			
		int input = 3;
		boolean boo = input>10;
		
		System.out.println("input:"+input);
		if(input==1){System.out.println("1번 입력");
		}
		if(input==2){System.out.println("2번 입력");
		}
		if(input==3){System.out.println("3번 입력");
		}
			
			
		}//main end
} // class end
