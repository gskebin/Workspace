package com.am.bookex;

public class Eint3 {

	
		public static void main(String[] args) {
			
			byte var1= 127;
			short var2 = 32000;
			int var3 = 550;
			
			System.out.println("var1의 값:"+var1);
			System.out.println("var2의 값:"+var2);
			System.out.println("var3의 값:"+var3);
		}
}
