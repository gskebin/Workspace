package com.am.bookex;

public class Eint2 {

	
		public static void main(String[] args) {
			
			byte var1 = 127;
			int var2 = 550L;
			System.out.println("var2의 값 : "+ var2);
			
		}
}
