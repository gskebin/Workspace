package com.am.bookex;

/*
 *- 관계(비교)연산자 : >=(크거나같다), >(크다), == (같다) , !=(같지 않다), <(작다) , <=(작거나같다)  
 *  
 *  *관계연산자의 특징 무조건 boolean형(true 아니면 false )로 결과가 나온다.
 *  =>조건식에 많이 사용됨.
 */

public class Ex04 {

		public static void main(String[] args) {
			
			int su1 = 20;
			int su2 = 30;
			
			boolean res = su1 > su2;
			System.out.println("결과:"+res);
			
			
		}
}
