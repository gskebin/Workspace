package com.am.bookex;

public class E210 {

		public static void main(String[] args) {
			
			short a,b ;
			a = b = 10;
			
			short c =(short)(a+b);
				
			
			System.out.println("c의값:" + c);
			
			
		}
	
}
