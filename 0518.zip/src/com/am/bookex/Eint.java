package com.am.bookex;

public class Eint {

		public static void main(String[] args) {
			
			byte var1 = 128;
			
			System.out.println("var1의 값:"+var1);
			
		}
}
