package com.am.bookex;

public class Efloat2 {

		public static void main(String[] args) {
			
			float var1,var2;
			var1 = 3.4f; //float 형으로 명시한것
			var2 = 550;
			System.out.println("var1의 값:"+ var1);
			System.out.println("var2의 값:"+ var2);
			
			
		}
}
