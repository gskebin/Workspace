package com.am.bookex;

public class E29 {

		public static void main(String[] args) {
			
	
	int a , b, c;
	
	a= 20;
	b= 7;
	c= a+b ; 
	System.out.println("a+b="+c);

	c = a-b ; 
	System.out.println("a-b="+c);
	
	c=a%b;
	System.out.println("a%b="+c);
		}
	
}
