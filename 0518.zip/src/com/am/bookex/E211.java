package com.am.bookex;

public class E211 {

	
		public static void main(String[] args) {
		
			int a =10;
			int b = 7;
			System.out.println(a+b);
			System.out.println("변수a:"+a);
			
			System.out.println(a+=b);
			System.out.println("변수a:" + a );
		}
}
