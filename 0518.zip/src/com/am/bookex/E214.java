package com.am.bookex;

public class E214 {

		public static void main(String[] args) {
			
			int a = 10;
			int b = 7;
			
			int c = a&b;
			System.out.println("변수c의 값:"+c);
		}
}
