package com.am.bookex;

public class Ex32 {

	
		public static void main(String[] args) {
			
			int su1 =50;
			String str = "50미만";
			
			if(su1>=50) str="50이상";
			
				System.out.println(str+"입니다");
			}
		
}
