package com.am.bookex;

public class Echar2 {

	
		public static void main(String[] args) {
			
			char c = '\u0042';
			System.out.println("c의 값은 :"+c);
			
		}
}
