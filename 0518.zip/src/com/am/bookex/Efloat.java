package com.am.bookex;

public class Efloat {

	
		public static void main(String[] args) {
			
			
			float var1 =(float)3.4;
			float var2 =3.4f;
			
			System.out.println("var1의 값 : "+var1);
			System.out.println("var2의 값 : "+var2);
			
		}
}
