package 오후;

public class Test04 {

	public static void main(String[] args) {
		
		int a =10, b, c, d ,e,f; 
		
		b= a-- * 10;
		c= ++a + ++b;
		d= c--% b;
		e= --d;
		f= ++e + a;
	}
	
	
	
}
