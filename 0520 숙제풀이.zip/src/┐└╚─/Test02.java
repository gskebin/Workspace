package 오후;

public class Test02 {

	
		public static void main(String[] args) {
			
			System.out.println('a'+20); // 유니코드 117
			System.out.println("a"+20); //문자열+숫자
			
			int x = 10, y = 10 ; 
			System.out.println("x+1:"+(x+1));
			System.out.println("x:"+x);
			
			System.out.println("++y:"+(++y));
			System.out.println("y:"+y);
			//////////////////////////////////////
			int n1 =100, n2 = 100;
			System.out.println("++n1:"+(++n1));
			System.out.println("n1:"+n1);
			
			System.out.println("++n2:"+(++n2));
			System.out.println("n2:"+n2);
			
		}
}
