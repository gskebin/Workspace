package 오후;

import java.util.Scanner;

public class Test05 {

	
	
		public static void main(String[] args) {
			
		 String name;
		 
		 Scanner scan = new Scanner(System.in);
		 
		 System.out.println("이름:");
		 
		 name = scan.next();
		 
		 System.out.println(name+"님 반갑습니다.");
		 
			
			
		}
}
