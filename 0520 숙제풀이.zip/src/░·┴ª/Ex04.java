package 과제;

public class Ex04 {

	
		public static void main(String[] args) {
			
			
		}
}
