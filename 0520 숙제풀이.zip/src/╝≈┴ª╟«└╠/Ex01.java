package 숙제풀이;

import java.util.Scanner;

public class Ex01 {

	
			public static void main(String[] args) {
				
				
				double
				w*h
				2*(w+h)
				println
			}
}
