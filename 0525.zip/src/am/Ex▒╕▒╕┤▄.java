package am;

public class Ex구구단 {

	public static void main(String[] args) {
		
		
		for(int dan =2; dan<10; dan++){
			for (int i = 1; i <10; i++) {
				System.out.println(dan+"x"+i+"="+(dan*i));
			}
		}
	}
}
