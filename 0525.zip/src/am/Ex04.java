package am;

public class Ex04 {

}
