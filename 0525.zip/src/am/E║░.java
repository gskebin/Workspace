package am;

public class E별 {

	public static void main(String[] args) {
		
		System.out.println("프로그램 시작");
		for (int i = 0; i < 3 ; i++) {
			for (int j = 0; j < 10; j++) {
				System.out.print("*");
		}	
		System.out.println("**"); //줄바꿈
		}
		System.out.println("종료"); //줄바꿈
	}
}
