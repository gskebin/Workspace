package parkjugod;

public class Ex20 {

	public static void main(String[] args) {
		
		
		
	}
}
