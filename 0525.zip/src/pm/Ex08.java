package pm;

import java.util.Scanner;

public class Ex08 {

	public static void main(String[] args) {
		
		int a;
		Scanner scan = new Scanner(System.in);
		System.out.println("정수를 입력하시오");
		a= scan.nextInt();
		System.out.println(a+" "+(a+10));
		}
		
	}
