package pm;

public class Ex09 {

	public static void main(String[] args) {
		
		int a=1;
		int b=-2;
		for (int i = 1; i <100; i++) {
			
		}
		}
	}
