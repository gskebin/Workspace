package pm;

public class Ex00 {

	public static void main(String[] args) {
		
		int n =12;
		while(n>0){
			n=n-2;
			if(n==6){
				break;
			}
			System.out.println(n);
		}
	}
}
