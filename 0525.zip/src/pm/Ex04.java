package pm;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		
		int a;
		Scanner scan = new Scanner(System.in);
		System.out.println("정수를 입력하시오");
		a=scan.nextInt();
		if(a>1000000000){
			System.out.println("");
		}
	
		}
		
	}

