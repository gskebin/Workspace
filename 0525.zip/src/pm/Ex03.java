package pm;

import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		
		int a;
		System.out.println("정수를 입력하시오");
		Scanner scan =new Scanner(System.in);
		a= scan.nextInt();
		if(a>1000000000){
			System.out.println("");
		}
		
		System.out.println("입력하신 정수는");
	}
}
